title: gitlab搭建
date: '2019-09-27 21:13:47'
updated: '2019-10-17 14:00:43'
tags: [centerOS, gitlab]
permalink: /articles/2019/09/27/1571280300157.html
---
![](https://img.hacpai.com/bing/20180127.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# Gitlab搭建

## 一. 安装环境

系统：CenterOS7

### 1.  配置ssh与http

<!--more-->

```bash
sudo yum install -y curl policycoreutils-python openssh-server
sudo systemctl enable sshd
sudo systemctl start sshd

sudo firewall-cmd --permanent --add-service=http
sudo systemctl reload firewalld
```

### 2. 安装右键服务器postfix

```bash
sudo yum install postfix
sudo systemctl enable postfix
sudo systemctl start postfix
```

## 二. 配置镜像

由于国外镜像下载极其困难，需要切换到国内镜像，官方支持的国内镜像是清华大学的镜像站，地址：[https://mirror.tuna.tsinghua.edu.cn/help/gitlab-ce/](https://link.jianshu.com/?t=https%3A%2F%2Fmirror.tuna.tsinghua.edu.cn%2Fhelp%2Fgitlab-ce%2F)

### 1. 首先信任GitLab的GPG公钥：

```shell
curl https://packages.gitlab.com/gpg.key 2> /dev/null | sudo apt-key add - &>/dev/null
```

### 2. 新建repo

新建 `/etc/yum.repos.d/gitlab-ce.repo`，内容为:

```csharp
[gitlab-ce]
name=Gitlab CE Repository
baseurl=https://mirrors.tuna.tsinghua.edu.cn/gitlab-ce/yum/el$releasever/
gpgcheck=0
enabled=1
```

### 3. 执行下载

```shell
sudo yum makecache
sudo EXTERNAL_URL="http://192.168.1.3" yum install -y gitlab-ce
```

其中`EXTERNAL_URL`参数用于指定gitlav的访问地址；后续可在`/etc/gitblab/gitlab.rb` 中修改配置。

执行命令配置生效

```shell
gitlab-ctl reconfigure
```

## 三. GitLab配置邮件服务

### 1. 编辑`gitlab.rab`，添加内容：

``` shell
vi /etc/gitlab/gitlab.rb
```

- smtp_addressQQ邮箱服务器是smtp.qq.com
- smtp_port端口465 （注意，不要用25端口）
- smtp_user_name 配置自己的QQ号

``` shell
gitlab_rails['smtp_enable'] = true
gitlab_rails['smtp_address'] = "smtp.qq.com"
gitlab_rails['smtp_port'] = 465
gitlab_rails['smtp_user_name'] = "xxxxxx@qq.com"  #  QQ号
gitlab_rails['smtp_password'] = "*************"             # QQ授权码
gitlab_rails['smtp_domain'] = "smtp.qq.com"
gitlab_rails['smtp_authentication'] = "login"
gitlab_rails['smtp_enable_starttls_auto'] = true
gitlab_rails['smtp_tls'] = true
gitlab_rails['gitlab_email_from'] = 'xxxxxx@qq.com'   #  QQ号
```

执行命令配置生效

```shell
gitlab-ctl reconfigure
```

### 2. 测试邮箱

执行 gitlab-rails console进入控制台交互界面, 然后在控制台提示符后输入下面内容发送一封测试邮件，测试完成后exit()退出。

``` 
gitlab-rails console
Notify.test_email('xxxxxxxx@qq.com', '邮件标题_test', '邮件正文_test').deliver_now
```

![1569566492185.png](https://img.hacpai.com/file/2019/10/1569566492185-a28216f6.png)



## 四. GitLab备份

GitLab运行过程中，为了防止出现意外情况，需要做好备份。

### 1. 备份配置

默认 Gitlab 的备份文件会创建在`/var/opt/gitlab/backups`文件夹中，格式为`时间戳_日期_版本号_gitlab_backup.tar`，例如：`1515031353_2018_01_04_10.3.2_gitlab_backup.tar`。
修改备份文件夹，需要修改配置文件`/etc/gitlab/gitlab.rb`中的：

```bash
gitlab_rails['backup_path'] = '/your/backups'
```

然后`gitlabctl-reconfigure`生效。

### 2. 手动备份

命令：`gitlab-rake gitlab:backup:create`

会在命令执行的时间点，在你配置的文件夹或者默认文件夹创建一个备份文件。

如遇权限问题，则给git用户分配备份目录权限即可：

```ruby
chown git /var/opt/gitlab/backups

chmod 777 /var/opt/gitlab/backups
```

### 3. 自动备份

Gitlab 支持 `crontab` 来创建计划任务，执行命令：`sudo crontab -e -u root`，为 root 用户，创建并编辑 crontab。
例如，crontab每天的23:00自动执行auto_backup.sh脚本，

```bash
0 23 * * * root /var/opt/gitlab/backups/auto_backup.sh -D 1
```

脚本内容如下：`gitlab-rake gitlab:backup:create`

### 4. 备份恢复

先停止 gitlab 相关服务：

```shell
sudo gitlab-ctl stop unicorn
sudo gitlab-ctl stop sidekiq
```

执行备份恢复命令：

```shell
gitlab-rake gitlab:backup:restore BACKUP=1515031353_2018_01_04_10.3.2
```

为了防止有问题，还是需要执行重新配置，用来重新配置和启动：

```shell
gitlab-ctl reconfigure
```
