title: logback
date: '2019-04-24 05:24:15'
updated: '2019-04-24 05:24:15'
tags: [logback, springboot]
permalink: /articles/2019/04/24/1571280298967.html
---
# logback

## 一、logback的组成

<!-- more -->

logback由三大模块组成：

1. logback-core：核心代码模块

2. logback-classic：log4j的一个改良版本，同事实现了slf4j的接口，便于后期切换日志组件

3. logback-access：访问模块与Servlet容器集成提供通过Http来访问日志的功能

   

## 二、logback的使用

引入maven依赖

```xml
<!--这个依赖直接包含了 logback-core 以及 slf4j-api的依赖-->
<dependency>
     <groupId>ch.qos.logback</groupId>
     <artifactId>logback-classic</artifactId>
     <version>1.2.3</version>
</dependency>
```

引入jar包之后就可以在代码中使用slf4j的接口获取Logger输出日志了。

```java
//这是slf4j的接口，由于我们引入了logback-classic依赖，所以底层实现是logback
private static final Logger LOGGER = LoggerFactory.getLogger(Test.class);

public static void main(String[] args) throws InterruptedException {
    LOGGER.info("hello world");
}
```

当然，大多数时候我们会通过自定义配置文件来个性化日志的输出方案

## 三、logback的配置

在`resource`目录下创建`logback.xml`或者`logback-spring.xml`文件，完整配置如下：

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<configuration scan="true" scanPeriod="30 seconds" debug="true">
	<!-- logback的根节点 <configuration>的属性scan、scanPeriod、debug
       scan:        当此属性设置为true时，配置文件如果发生改变，将会被重新加载，默认值为true。
       scanPeriod:  设置监测配置文件是否有修改的时间间隔，如果没有给出时间单位，默认单位是毫秒。当scan为true时，此属性生效。默认的时间间隔为1分钟。
       debug:       当此属性设置为true时，将打印出logback内部日志信息，实时查看logback运行状态。默认值为false。
     -->

	<!-- 定义日志文件的存储地址 -->
	<property name="LOG_HOME" value="./logback-study/logs"/>
	<!-- 定义日志文件名称 -->
	<property name="LOG_NAME" value="logback-study"/>
	<!-- 格式化输出：
	   %d		    表示日期，
	   %thread		表示线程名，
	   %level		日志级别从左显示5个字符宽度，
	   %thread		线程名
	   %file		文件名
	   %line 		行号
	   %m			日志消息，
	   %n			换行符，
	   %X{traceId}	 自定义设置的参数
	   %mdc			自定义参数
   -->
	<property name="LOG_PATTERN" value="%d{yyyy-MM-dd HH:mm:ss.SSS} %-5level [%thread] [%logger] line:%line: %m%n"/>

	<!-- appender是configuration的子节点，是负责写日志的组件 -->
	<!-- 控制台输出 -->
	<appender name="STDOUT" class="ch.qos.logback.core.ConsoleAppender">
		<!-- 定义一个过滤器 -->
		<filter class="ch.qos.logback.classic.filter.LevelFilter">
			<level>INFO</level>
			<onMatch>ACCEPT</onMatch>
			<onMismatch>DENY</onMismatch>
		</filter>
		<encoder>
			<pattern>${LOG_PATTERN}</pattern>
			<charset>utf8</charset>
		</encoder>
	</appender>

	<!-- INFO日志 appender: 按照每天生成日志文件 -->
	<appender name="INFO-APPENDER" class="ch.qos.logback.core.rolling.RollingFileAppender">
		<!-- 过滤器，记录info级别以上的日志 -->
		<filter class="ch.qos.logback.classic.filter.LevelFilter">
			<level>ERROR</level>
			<onMatch>ACCEPT</onMatch>
			<onMismatch>DENY</onMismatch>
		</filter>
		<!-- 写入的日志文件名，可以使相对目录也可以是绝对目录，如果上级目录不存在则自动创建 -->
		<file>${LOG_HOME}/${LOG_NAME}-info.log</file>
		<!-- 如果为true表示日志被追加到文件结尾，如果是false表示清空文件 -->
		<append>true</append>
		<rollingPolicy class="ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy">
			<!-- 日志文件输出的文件名: %d可以包含一个Java.text.SimpleDateFormat指定的时间格式 -->
			<fileNamePattern>${LOG_HOME}/${LOG_NAME}-info.%d{yyyy-MM-dd}.%i.log</fileNamePattern>
			<!-- 日志文件保存历史数量:控制保留的归档文件的最大数量，如果超出数量就删除旧文件 -->
			<maxHistory>30</maxHistory>
			<!-- 文件大小超过100MB归档 -->
			<maxFileSize>100MB</maxFileSize>
		</rollingPolicy>
		<encoder class="ch.qos.logback.classic.encoder.PatternLayoutEncoder">
			<pattern>${LOG_PATTERN}</pattern>
			<charset>utf8</charset>
		</encoder>
	</appender>

	<!-- 错误日志 appender: 按照每天生成日志文件 -->
	<appender name="ERROR-APPENDER" class="ch.qos.logback.core.rolling.RollingFileAppender">
		<!-- 过滤器，只记录error级别的日志 -->
		<filter class="ch.qos.logback.classic.filter.LevelFilter">
			<level>ERROR</level>
			<onMatch>ACCEPT</onMatch>
			<onMismatch>DENY</onMismatch>
		</filter>
		<!-- 日志名称 -->
		<file>${LOG_HOME}/${LOG_NAME}-error.log</file>
		<append>true</append>
		<!-- 每天生成一个日志文件，保存30天的日志文件 -->
		<rollingPolicy class="ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy">
			<!-- 日志文件输出的文件名:按天回滚 daily -->
			<fileNamePattern>${LOG_HOME}/${LOG_NAME}-error.%d{yyyy-MM-dd}.%i.log</fileNamePattern>
			<!-- 日志文件保留天数 -->
			<maxHistory>30</maxHistory>
			<!-- 文件大小超过100MB归档 -->
			<maxFileSize>100MB</maxFileSize>
		</rollingPolicy>
		<encoder class="ch.qos.logback.classic.encoder.PatternLayoutEncoder">
			<pattern>${LOG_PATTERN}</pattern>
			<charset>utf8</charset>
		</encoder>
	</appender>


	<!-- name:指定项目中某个包，当有日志操作行为时的日志记录级别
		级别依次为【从高到低】：FATAL > ERROR > WARN > INFO > DEBUG > TRACE
		additivity=false 表示匹配之后，不再继续传递给其他的logger
	-->
	<logger name="com.logback.logbackstudy" level="INFO" additivity="false">
		<appender-ref ref="STDOUT"/>
		<appender-ref ref="INFO-APPENDER"/>
		<appender-ref ref="ERROR-APPENDER"/>
	</logger>

	<!-- 控制台输出日志级别 -->
	<root level="INFO">
		<appender-ref ref="STDOUT"/>
	</root>

</configuration>
```

引用：[Logback配置解析——Flylinran]:https://www.jianshu.com/p/5fb74d28e306