title: ssh-config
date: '2019-04-21 06:41:49'
updated: '2019-04-21 06:41:49'
tags: [git, ssh]
permalink: /articles/2019/04/21/1571280300636.html
---
## 一. 使用SSH

此处以github为例，配置ssh连接

<!--more-->

本地环境：windows10 64位

##### 使用步骤

1. 打开git bash，进入到本地默认ssh目录
   ```
   cd ~/.ssh
   ```

2. 生成ssh秘钥

   ```
   ssh-keygen -t rsa -C "email@example.com"
   ```

   代码参数含义

   - -t: 指定秘钥类型，默认是rsa;
   - -C:设置注释文字
   - -f: 指定秘钥文件存储文件名

   直接回车，使用默认配置，完成后可在目录下看到刚生成的文件: id_rsa和id_rsa.pub

3. 在GitHub账户中添加公钥

   登陆github，在settings中设置 ``SSH and GPG keys``按钮，点击``New SSH key``，title随意填，key中填入上一步 生成的id_rsa.pub中的内容。

4. 测试

   ```
   ssh -T git@github.com
   ```

   会得到github 的响应

   ```
   PTY allocation request failed on channel 0
   Hi xxx! You've successfully authenticated， but GitHub does not provide shell access.
   Connection to github.com closed.
   ```

   到这里则表示使用ssh连接github成功。

   **需要注意的是：配置完ssh后，代码仓库需要使用ssh链接**



## 二. 使用ssh-config

由于在正常使用过程中，我们不可能只配置一个ssh环境，当有多个连接需求时就必须配置多个私钥与公钥。

1. 和之前一样先生成公钥和私钥

   ```
   ssh-keygen -t rsa -C "email@example.com"
   ```

   这边的文件名最好自定义，以免使用默认的以后被覆盖

   文件名定义为 ``id_rsa_github``

   然后一路回车，同样可以在.ssh目录中看到新生成的两个文件

2. 一样将公钥加入到github中

3. 在.ssh目录中创建``config``文件

   配置内容如下：

   ```
   AddKeysToAgent yes
   ForwardAgent yes
   
   Host github  # 别名（自己随便定义）
    HostName github.com #目标主机的主机名，就是使用ssh后面跟的地址名称
    IdentityFile C:/Users/xxx/.ssh/id_rsa_github # 私钥路径
    User git # 指定的登陆用户名 github必须配置为git，否则无法成功
   ```

4. 测试

   直接使用命令即可

   ```
   ssh github
   ```

   当有多个连接时增加第3步中 4-7行的配置就行

#### 补充：

 	当出现ssh -T git@xxx 失效时，可配合使用ssh-agent实现正常的连接。

1. 需要开启ssh-agent ,在shell中输入命令：

	```
	ssh-agent bash
	```

2. 手动添加对用 的私钥文件

   ``````
   ssh-add xxx  //默认路径为C:/Users/用户名/.ssh/xxxx
   ``````